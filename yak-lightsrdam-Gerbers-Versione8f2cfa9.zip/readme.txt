Project Name: lights_rdAm
Project Version: e8f2cfa9
Project Url: https://www.flux.ai/yak/lightsrdam

Project Description:
PCB in the shape of Road America racetrack. LED's follow the race car path using existing lap time data.


